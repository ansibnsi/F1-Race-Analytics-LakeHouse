# Data Quality Checks

Implemented in [`notebooks/04_data_quality_checks.py`](../notebooks/04_data_quality_checks.py),
run as the final step of the pipeline against the Silver layer (the point
where checks catch problems before they propagate into Gold/Power BI).

## Checks

| Category | Check | Threshold / rule | On failure |
|---|---|---|---|
| Completeness | `silver_results.race_id` non-null | ≥ 99% of rows | Logged; fails run if `--fail-on-error` |
| Completeness | `silver_results.driver_id` non-null | ≥ 99% of rows | Logged; fails run if `--fail-on-error` |
| Completeness | `silver_results.constructor_id` non-null | ≥ 99% of rows | Logged; fails run if `--fail-on-error` |
| Completeness | `silver_results.points` non-null | ≥ 99% of rows | Logged; fails run if `--fail-on-error` |
| Duplicates | No duplicate `(race_id, driver_id)` pairs | 0 duplicates | Logged; fails run if `--fail-on-error` |
| Referential integrity | Every `driver_id` in results exists in `silver_drivers` | 0 orphan rows | Logged; fails run if `--fail-on-error` |
| Referential integrity | Every `constructor_id` in results exists in `silver_constructors` | 0 orphan rows | Logged; fails run if `--fail-on-error` |
| Referential integrity | Every `race_id` in results exists in `silver_races` | 0 orphan rows | Logged; fails run if `--fail-on-error` |
| Plausibility | `position` between 1 and 30 | 0 out-of-range rows | Logged; fails run if `--fail-on-error` |
| Plausibility | `points` between 0 and 26 (sprint + race max) | 0 out-of-range rows | Logged; fails run if `--fail-on-error` |

## Why these specific checks

- **Completeness on foreign keys and points** — a null `driver_id` or
  `points` value in a result row usually means an upstream extract or join
  problem, not a legitimate business case, so it's worth catching early.
- **Duplicates on `(race_id, driver_id)`** — a driver can only finish a
  given race once; a duplicate almost always means a source file was
  ingested twice or a join fanned out unexpectedly. The included sample
  data deliberately contains one such duplicate so the check has
  something to catch on a first run.
- **Referential integrity** — catches typos or mismatched IDs between
  source files (e.g. a `results` row referencing a `driver_id` that
  doesn't exist in `drivers`), which silently produces `null`s after a
  left join if not checked explicitly.
- **Plausibility ranges** — position and points have known real-world
  bounds in Formula 1; anything outside them indicates a parsing or
  mapping bug rather than a genuine data point.

## Running in strict mode

By default, checks are logged but don't stop the pipeline. Pass
`--fail-on-error` (or wire the equivalent into the Fabric pipeline's
Notebook activity settings) to make a failing check abort the run — useful
once the pipeline is trusted enough that a quality failure should block
downstream consumption (e.g. a Power BI refresh) rather than just being
logged for review.

## Extending

- Add a `dq_results` Delta table that the notebook appends each run's
  `CheckResult` rows into, so quality trends can be tracked in Power BI
  over time rather than only visible in run logs.
- Add schema-drift detection (new/missing/retyped columns) as an
  additional check category.
- Swap the hand-rolled checks here for Great Expectations or Fabric's
  built-in data quality tooling if the check set grows significantly.
