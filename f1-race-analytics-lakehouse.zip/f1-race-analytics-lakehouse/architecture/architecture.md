# Architecture

## Overview

This project implements a medallion (Bronze/Silver/Gold) lakehouse for
Formula 1 racing data on Microsoft Fabric. Fabric Data Factory handles
ingestion/orchestration; PySpark notebooks handle transformation; Delta
tables in a Fabric Lakehouse are the storage layer; Power BI (via Direct
Lake mode) is the consumption layer.

```mermaid
flowchart LR
    subgraph Source
        A[Source files / APIs<br/>races, drivers, constructors, results]
    end

    subgraph ADF["Fabric Data Factory"]
        B[Copy Activity]
        C[Notebook Activities]
    end

    subgraph LH["Fabric Lakehouse"]
        D[(Files/raw)]
        E[(Tables/bronze_*)]
        F[(Tables/silver_*)]
        G[(Tables/gold_*)]
    end

    subgraph NB["PySpark Notebooks"]
        H[01_bronze_ingestion]
        I[02_silver_transformation]
        J[03_gold_aggregation]
        K[04_data_quality_checks]
    end

    L[Power BI<br/>Direct Lake]

    A --> B --> D
    D --> H --> E
    E --> I --> F
    F --> J --> G
    F --> K
    G --> K
    G --> L
    C -. triggers .-> H
    C -. triggers .-> I
    C -. triggers .-> J
    C -. triggers .-> K
```

## Layers

### Bronze
Raw CSV rows landed as Delta tables with minimal change: added
`_ingested_at`, `_source_file`, `_batch_id` columns. Append-only — this is
the replay source if a downstream transform needs to be re-run from
scratch.

### Silver
One cleaned, typed, deduplicated table per source entity:
`silver_races`, `silver_drivers`, `silver_constructors`, `silver_results`.
`silver_results` is enriched with driver name, constructor name, and race
details via joins, so Gold-layer aggregation doesn't need to repeat the
same joins in every mart.

### Gold
Business-facing marts, shaped around specific reporting questions:

| Table | Grain | Purpose |
|---|---|---|
| `gold_driver_standings` | one row per driver per season | Points, wins, podiums, average finish position |
| `gold_constructor_standings` | one row per constructor per season | Points, wins, 1-2 finishes |
| `gold_race_summary` | one row per race | Winner, pole position, fastest lap, number of finishers/retirements |

## Partitioning strategy

- **Bronze/Silver `results` tables**: partitioned by `season` — results
  are almost always queried/filtered by season, and this keeps individual
  partition files a manageable size as more seasons are added.
- **Gold standings tables**: partitioned by `season` as well, so a Power
  BI report filtered to "this season" only scans the relevant partition.
- **`races`, `drivers`, `constructors`**: small reference tables, left
  unpartitioned — partitioning overhead isn't worth it at this size.
- `OPTIMIZE ... ZORDER BY (driver_id)` (or `constructor_id`) is run
  periodically on the larger Silver/Gold tables to speed up point lookups
  once file counts grow.

## Data quality checks

Run as the last step in the pipeline (`04_data_quality_checks`), against
both Silver and Gold tables:

| Check type | Example | Behavior on failure |
|---|---|---|
| Completeness | `driver_id`, `race_id`, `constructor_id` non-null above 99% | Logged; fails pipeline if `fail_on_error=True` |
| Consistency | Every `results.driver_id` exists in `drivers`; `position` between 1 and 30; `points` >= 0 | Logged with offending row count |
| Duplicates | No duplicate `(race_id, driver_id)` in `results` | Logged with duplicate row count; fails pipeline if `fail_on_error=True` |

See [`docs/data_quality_checks.md`](../docs/data_quality_checks.md) for
the full list, thresholds, and how results are surfaced.

## Orchestration

`fabric/pipeline_definition.md` describes a Data Factory pipeline with:
1. **Copy Activity** — lands source files into `Files/raw/`
2. **Notebook Activity** — runs `01_bronze_ingestion`
3. **Notebook Activity** — runs `02_silver_transformation`
4. **Notebook Activity** — runs `03_gold_aggregation`
5. **Notebook Activity** — runs `04_data_quality_checks`, gating downstream
   consumption (e.g. a Power BI dataset refresh) on the checks passing

Each notebook activity depends on the previous one succeeding, mirroring
the Bronze → Silver → Gold dependency chain.

## Consumption

Power BI connects to the `gold_*` Delta tables using **Direct Lake mode**
(Fabric-native — queries the Delta tables directly with no import/refresh
step), so dashboards reflect the latest successful pipeline run without a
separate Power BI refresh schedule to manage. See
[`powerbi/dashboard_notes.md`](../powerbi/dashboard_notes.md) for the
report pages and key measures.
