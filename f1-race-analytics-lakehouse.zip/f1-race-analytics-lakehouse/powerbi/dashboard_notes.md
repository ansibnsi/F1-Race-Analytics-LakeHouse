# Power BI Dashboard

Connects to the Gold layer (`gold_driver_standings`,
`gold_constructor_standings`, `gold_race_summary`) using **Direct Lake
mode**, so the report always reflects the latest successful pipeline run
with no separate import/refresh schedule to manage.

## Report pages

### 1. Season Overview
- **Card visuals**: total races run this season, current points leader
  (driver), current points leader (constructor)
- **Line chart**: cumulative points by round, one line per driver (top 6
  by current standing, to keep it readable)
- **Table**: `gold_race_summary` — race name, winner, winning constructor,
  retirements, sorted by round

### 2. Driver Standings
- **Bar chart**: `total_points` by `driver_name`, sorted descending
- **Table**: full `gold_driver_standings` — standing, driver, points,
  wins, podiums, average finish position
- **Slicer**: season

### 3. Constructor Standings
- **Bar chart**: `total_points` by `constructor_name`
- **Table**: full `gold_constructor_standings`
- **Slicer**: season

### 4. Race Detail
- **Table**: `gold_race_summary` detail, filterable by race
- **KPI visual**: retirements as a percentage of total entrants per race

## Key DAX measures

```dax
Total Points =
SUM(gold_driver_standings[total_points])

Wins =
SUM(gold_driver_standings[wins])

Podium Rate =
DIVIDE(
    SUM(gold_driver_standings[podiums]),
    SUM(gold_driver_standings[races_entered]),
    0
)

Points Per Race =
DIVIDE(
    SUM(gold_driver_standings[total_points]),
    SUM(gold_driver_standings[races_entered]),
    0
)

Retirement Rate =
DIVIDE(
    SUM(gold_race_summary[retirements]),
    SUM(gold_race_summary[total_entrants]),
    0
)
```

## Relationships

| Table | Relationship |
|---|---|
| `gold_driver_standings[season]` <-> `gold_race_summary[season]` | Many-to-one, used for season-level slicers across pages |
| `gold_constructor_standings[season]` <-> `gold_race_summary[season]` | Many-to-one |

## Setting it up

1. In Power BI Desktop (or the Fabric workspace), choose **Get Data ->
   OneLake data hub** and select this Lakehouse.
2. Choose **Direct Lake** as the connection mode when prompted.
3. Select the `gold_driver_standings`, `gold_constructor_standings`, and
   `gold_race_summary` tables.
4. Build the pages/visuals above, or recreate them from a `.pbix`
   template if you export one from your own workspace and want to check
   it into this repo (not included here since `.pbix` files are binary
   and don't diff well in git — a `.pbip` (Power BI Project, text-based)
   export is a better fit for version control if you want to commit the
   report definition itself).
