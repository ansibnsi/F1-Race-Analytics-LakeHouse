"""
02_silver_transformation
--------------------------
Cleans, types, and deduplicates each Bronze table into Silver. Enriches
`silver_results` with driver/constructor/race names so Gold-layer marts
don't need to repeat the same joins.

Locally: python notebooks/02_silver_transformation.py --local
"""

from pyspark.sql import functions as F, Window

from spark_utils import get_arg_parser, get_spark, resolve_paths

# %% -------------------------------------------------------------------
def load_bronze(spark, tables_root: str, name: str):
    return spark.read.format("delta").load(f"{tables_root}/bronze_{name}")


# %% -------------------------------------------------------------------
def build_silver_races(spark, tables_root):
    df = load_bronze(spark, tables_root, "races")
    return (
        df.withColumn("race_date", F.to_date("race_date"))
        .withColumn("season", F.col("season").cast("int"))
        .withColumn("round", F.col("round").cast("int"))
        .dropDuplicates(["race_id"])
        .select("race_id", "season", "round", "race_name", "circuit", "race_date")
    )


def build_silver_drivers(spark, tables_root):
    df = load_bronze(spark, tables_root, "drivers")
    return (
        df.withColumn("date_of_birth", F.to_date("date_of_birth"))
        .dropDuplicates(["driver_id"])
        .select("driver_id", "driver_name", "nationality", "date_of_birth")
    )


def build_silver_constructors(spark, tables_root):
    df = load_bronze(spark, tables_root, "constructors")
    return df.dropDuplicates(["constructor_id"]).select(
        "constructor_id", "constructor_name", "nationality"
    )


def build_silver_results(spark, tables_root):
    df = load_bronze(spark, tables_root, "results")

    df_typed = (
        df.withColumn("grid", F.col("grid").cast("int"))
        .withColumn("position", F.col("position").cast("int"))
        .withColumn("points", F.col("points").cast("double"))
    )

    # Deduplicate on the natural key (race_id, driver_id), keeping the
    # most recently ingested row if the same result was loaded twice.
    window = Window.partitionBy("race_id", "driver_id").orderBy(F.col("_ingested_at").desc())
    df_deduped = (
        df_typed.withColumn("_rn", F.row_number().over(window))
        .filter(F.col("_rn") == 1)
        .drop("_rn")
    )

    races = build_silver_races(spark, tables_root)
    drivers = build_silver_drivers(spark, tables_root)
    constructors = build_silver_constructors(spark, tables_root)

    enriched = (
        df_deduped.join(races.select("race_id", "season", "round", "race_name"), "race_id", "left")
        .join(drivers.select("driver_id", "driver_name"), "driver_id", "left")
        .join(constructors.select("constructor_id", "constructor_name"), "constructor_id", "left")
    )

    return enriched.select(
        "race_id", "season", "round", "race_name",
        "driver_id", "driver_name",
        "constructor_id", "constructor_name",
        "grid", "position", "points", "status",
    )


# %% -------------------------------------------------------------------
def write_silver(df, tables_root: str, name: str, partition_by: list[str] | None = None):
    writer = df.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
    if partition_by:
        writer = writer.partitionBy(*partition_by)
    writer.save(f"{tables_root}/silver_{name}")
    print(f"silver_{name}: wrote {df.count()} rows")


def main():
    args = get_arg_parser(__doc__).parse_args()
    spark = get_spark(local=args.local)
    paths = resolve_paths(args, local=args.local)
    tables_root = paths["tables"]

    write_silver(build_silver_races(spark, tables_root), tables_root, "races")
    write_silver(build_silver_drivers(spark, tables_root), tables_root, "drivers")
    write_silver(build_silver_constructors(spark, tables_root), tables_root, "constructors")
    write_silver(
        build_silver_results(spark, tables_root), tables_root, "results", partition_by=["season"]
    )

    print("Silver transformation complete.")


if __name__ == "__main__":
    main()
