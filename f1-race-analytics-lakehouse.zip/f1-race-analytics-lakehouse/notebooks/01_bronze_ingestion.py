"""
01_bronze_ingestion
--------------------
Lands the raw F1 source CSVs (races, drivers, constructors, results) into
Bronze Delta tables, with ingestion metadata added. No business logic —
this layer should be a faithful, replayable copy of the source.

In Fabric: paste each `# %%` section into its own notebook cell, replacing
`spark = get_spark(local=True)` with nothing (the notebook's built-in
`spark` session is already available), and `paths = resolve_paths(...)`
with the Fabric Files/Tables paths directly.

Locally: python notebooks/01_bronze_ingestion.py --local
"""

from pyspark.sql import functions as F

from spark_utils import get_arg_parser, get_spark, resolve_paths

# %% -------------------------------------------------------------------
SOURCE_TABLES = ["races", "drivers", "constructors", "results"]


def ingest_table(spark, table_name: str, files_raw: str, tables_root: str, batch_id: str) -> int:
    raw_path = f"{files_raw}/{table_name}.csv"
    bronze_path = f"{tables_root}/bronze_{table_name}"

    df_raw = spark.read.option("header", True).option("inferSchema", True).csv(raw_path)

    df_bronze = (
        df_raw.withColumn("_ingested_at", F.current_timestamp())
        .withColumn("_source_file", F.lit(f"{table_name}.csv"))
        .withColumn("_batch_id", F.lit(batch_id))
    )

    (
        df_bronze.write.format("delta")
        .mode("append")
        .option("mergeSchema", "true")
        .save(bronze_path)
    )

    row_count = spark.read.format("delta").load(bronze_path).count()
    print(f"bronze_{table_name}: loaded {df_bronze.count()} rows this batch, {row_count} total")
    return row_count


# %% -------------------------------------------------------------------
def main():
    args = get_arg_parser(__doc__).parse_args()
    spark = get_spark(local=args.local)
    paths = resolve_paths(args, local=args.local)

    batch_id = spark.sql("SELECT uuid() AS id").collect()[0]["id"]
    print(f"Starting Bronze ingestion, batch_id={batch_id}")

    for table_name in SOURCE_TABLES:
        ingest_table(spark, table_name, paths["files_raw"], paths["tables"], batch_id)

    print("Bronze ingestion complete.")


if __name__ == "__main__":
    main()
