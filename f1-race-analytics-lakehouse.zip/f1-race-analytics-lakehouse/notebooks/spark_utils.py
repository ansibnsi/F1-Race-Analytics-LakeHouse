"""
notebooks/spark_utils.py
-------------------------
Small helper so the same transformation code can run two ways:

1. Inside a Microsoft Fabric notebook, where a `spark` session and the
   Lakehouse's `Files/` and `Tables/` paths already exist implicitly.
2. Locally, via `python notebooks/0X_....py --local`, using a throwaway
   local Spark + Delta session for fast iteration without a Fabric
   workspace.

Only the path resolution and session creation differ between the two
modes — the actual PySpark transformation logic in each notebook is
identical either way.
"""

import argparse
from pathlib import Path


def get_arg_parser(description: str) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument(
        "--local", action="store_true",
        help="Run against a local Spark+Delta session instead of a Fabric Lakehouse",
    )
    parser.add_argument(
        "--data-dir", default="data",
        help="Local directory containing the source CSVs (only used with --local on the first notebook)",
    )
    parser.add_argument(
        "--output-dir", default="./lakehouse_local",
        help="Local directory to use as the Lakehouse root (only used with --local)",
    )
    return parser


def get_spark(local: bool):
    """Return a Spark session. In Fabric, this would normally just be the
    notebook's built-in `spark` variable — this function exists so the
    same script also works standalone."""
    if not local:
        # Inside a Fabric notebook, `spark` is already provided in the
        # notebook's global scope. This branch is here so the module
        # still imports cleanly outside Fabric; Fabric notebooks should
        # just use the built-in `spark` object directly instead of
        # calling this function.
        raise RuntimeError(
            "get_spark(local=False) is a placeholder — inside a Fabric "
            "notebook, use the built-in `spark` session directly."
        )

    from pyspark.sql import SparkSession

    builder = (
        SparkSession.builder.appName("f1-lakehouse-local")
        .config("spark.jars.packages", "io.delta:delta-spark_2.12:3.1.0")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config(
            "spark.sql.catalog.spark_catalog",
            "org.apache.spark.sql.delta.catalog.DeltaCatalog",
        )
    )
    return builder.getOrCreate()


def resolve_paths(args, local: bool) -> dict:
    """Return the Files (raw landing) and Tables (Delta table) roots for
    either mode."""
    if local:
        base = Path(args.output_dir)
        return {
            "files_raw": str(Path(args.data_dir)),
            "tables": str(base / "Tables"),
        }
    return {
        "files_raw": "Files/raw",
        "tables": "Tables",
    }
