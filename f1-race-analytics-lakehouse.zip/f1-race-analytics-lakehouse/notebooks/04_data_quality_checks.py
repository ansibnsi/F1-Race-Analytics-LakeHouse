"""
04_data_quality_checks
-------------------------
Runs completeness, consistency, and duplicate checks against the Silver
and Gold layers, logs the results, and optionally fails the run if any
check falls below its threshold (--fail-on-error).

Locally: python notebooks/04_data_quality_checks.py --local
Locally, strict mode: python notebooks/04_data_quality_checks.py --local --fail-on-error
"""

from dataclasses import dataclass

from pyspark.sql import functions as F

from spark_utils import get_arg_parser, get_spark, resolve_paths

COMPLETENESS_THRESHOLD = 0.99  # 99% of rows must have required fields populated


@dataclass
class CheckResult:
    name: str
    passed: bool
    detail: str


# %% -------------------------------------------------------------------
def check_completeness(df, table_name: str, required_cols: list[str]) -> list[CheckResult]:
    results = []
    total = df.count()
    for col in required_cols:
        non_null = df.filter(F.col(col).isNotNull()).count()
        ratio = non_null / total if total else 1.0
        passed = ratio >= COMPLETENESS_THRESHOLD
        results.append(
            CheckResult(
                name=f"completeness:{table_name}.{col}",
                passed=passed,
                detail=f"{non_null}/{total} rows non-null ({ratio:.1%}, threshold {COMPLETENESS_THRESHOLD:.0%})",
            )
        )
    return results


def check_no_duplicates(df, table_name: str, key_cols: list[str]) -> CheckResult:
    total = df.count()
    distinct = df.select(*key_cols).distinct().count()
    duplicate_count = total - distinct
    return CheckResult(
        name=f"duplicates:{table_name}({','.join(key_cols)})",
        passed=duplicate_count == 0,
        detail=f"{duplicate_count} duplicate row(s) found on key ({', '.join(key_cols)})",
    )


def check_referential_integrity(df, fk_col: str, ref_df, ref_col: str, table_name: str) -> CheckResult:
    orphans = df.join(ref_df.select(ref_col), df[fk_col] == ref_df[ref_col], "left_anti")
    orphan_count = orphans.count()
    return CheckResult(
        name=f"referential_integrity:{table_name}.{fk_col}",
        passed=orphan_count == 0,
        detail=f"{orphan_count} row(s) in {table_name} with {fk_col} not found in reference table",
    )


def check_value_range(df, table_name: str, col: str, min_val, max_val) -> CheckResult:
    out_of_range = df.filter(
        F.col(col).isNotNull() & ((F.col(col) < min_val) | (F.col(col) > max_val))
    ).count()
    return CheckResult(
        name=f"range:{table_name}.{col}",
        passed=out_of_range == 0,
        detail=f"{out_of_range} row(s) with {col} outside [{min_val}, {max_val}]",
    )


# %% -------------------------------------------------------------------
def run_all_checks(spark, tables_root: str) -> list[CheckResult]:
    silver_results = spark.read.format("delta").load(f"{tables_root}/silver_results")
    silver_drivers = spark.read.format("delta").load(f"{tables_root}/silver_drivers")
    silver_constructors = spark.read.format("delta").load(f"{tables_root}/silver_constructors")
    silver_races = spark.read.format("delta").load(f"{tables_root}/silver_races")

    checks: list[CheckResult] = []

    checks += check_completeness(
        silver_results, "silver_results", ["race_id", "driver_id", "constructor_id", "points"]
    )
    checks.append(check_no_duplicates(silver_results, "silver_results", ["race_id", "driver_id"]))
    checks.append(
        check_referential_integrity(silver_results, "driver_id", silver_drivers, "driver_id", "silver_results")
    )
    checks.append(
        check_referential_integrity(
            silver_results, "constructor_id", silver_constructors, "constructor_id", "silver_results"
        )
    )
    checks.append(
        check_referential_integrity(silver_results, "race_id", silver_races, "race_id", "silver_results")
    )
    checks.append(check_value_range(silver_results, "silver_results", "position", 1, 30))
    checks.append(check_value_range(silver_results, "silver_results", "points", 0, 26))

    return checks


def report(checks: list[CheckResult]) -> bool:
    all_passed = True
    print("\n=== Data Quality Report ===")
    for c in checks:
        status = "PASS" if c.passed else "FAIL"
        print(f"[{status}] {c.name} — {c.detail}")
        all_passed = all_passed and c.passed
    print(f"\n{sum(c.passed for c in checks)}/{len(checks)} checks passed.\n")
    return all_passed


# %% -------------------------------------------------------------------
def main():
    parser = get_arg_parser(__doc__)
    parser.add_argument(
        "--fail-on-error", action="store_true",
        help="Exit with a non-zero status (failing the pipeline) if any check fails",
    )
    args = parser.parse_args()

    spark = get_spark(local=args.local)
    paths = resolve_paths(args, local=args.local)

    checks = run_all_checks(spark, paths["tables"])
    all_passed = report(checks)

    if not all_passed and args.fail_on_error:
        raise SystemExit("Data quality checks failed — see report above.")


if __name__ == "__main__":
    main()
