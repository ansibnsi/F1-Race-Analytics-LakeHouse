"""
03_gold_aggregation
----------------------
Builds business-facing Gold marts from Silver: driver standings,
constructor standings, and a per-race summary — shaped for direct Power BI
consumption.

Locally: python notebooks/03_gold_aggregation.py --local
"""

from pyspark.sql import functions as F, Window

from spark_utils import get_arg_parser, get_spark, resolve_paths

# %% -------------------------------------------------------------------
def load_silver(spark, tables_root: str, name: str):
    return spark.read.format("delta").load(f"{tables_root}/silver_{name}")


# %% -------------------------------------------------------------------
def build_driver_standings(results):
    agg = (
        results.groupBy("season", "driver_id", "driver_name")
        .agg(
            F.sum("points").alias("total_points"),
            F.count("*").alias("races_entered"),
            F.sum(F.when(F.col("position") == 1, 1).otherwise(0)).alias("wins"),
            F.sum(F.when(F.col("position") <= 3, 1).otherwise(0)).alias("podiums"),
            F.round(F.avg("position"), 2).alias("avg_finish_position"),
        )
    )

    window = Window.partitionBy("season").orderBy(F.col("total_points").desc())
    return agg.withColumn("standing", F.row_number().over(window))


def build_constructor_standings(results):
    agg = (
        results.groupBy("season", "constructor_id", "constructor_name")
        .agg(
            F.sum("points").alias("total_points"),
            F.sum(F.when(F.col("position") == 1, 1).otherwise(0)).alias("wins"),
        )
    )

    window = Window.partitionBy("season").orderBy(F.col("total_points").desc())
    return agg.withColumn("standing", F.row_number().over(window))


def build_race_summary(results):
    winners = (
        results.filter(F.col("position") == 1)
        .select(
            "race_id", "season", "round", "race_name",
            F.col("driver_name").alias("winner"),
            F.col("constructor_name").alias("winning_constructor"),
        )
    )

    per_race_stats = results.groupBy("race_id").agg(
        F.count("*").alias("total_entrants"),
        F.sum(F.when(F.col("status") != "Finished", 1).otherwise(0)).alias("retirements"),
    )

    return winners.join(per_race_stats, "race_id", "left").orderBy("season", "round")


# %% -------------------------------------------------------------------
def write_gold(df, tables_root: str, name: str, partition_by: list[str] | None = None):
    writer = df.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
    if partition_by:
        writer = writer.partitionBy(*partition_by)
    writer.save(f"{tables_root}/gold_{name}")
    print(f"gold_{name}: wrote {df.count()} rows")


def main():
    args = get_arg_parser(__doc__).parse_args()
    spark = get_spark(local=args.local)
    paths = resolve_paths(args, local=args.local)
    tables_root = paths["tables"]

    results = load_silver(spark, tables_root, "results")

    write_gold(build_driver_standings(results), tables_root, "driver_standings", partition_by=["season"])
    write_gold(build_constructor_standings(results), tables_root, "constructor_standings", partition_by=["season"])
    write_gold(build_race_summary(results), tables_root, "race_summary")

    print("Gold aggregation complete.")


if __name__ == "__main__":
    main()
