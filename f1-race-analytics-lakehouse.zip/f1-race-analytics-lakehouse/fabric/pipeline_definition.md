# Fabric Data Factory Pipeline

This describes the Data Factory pipeline to build in your Fabric
workspace to orchestrate the notebooks in this repo. (Fabric pipelines are
authored visually; this document is the design spec to build it from —
analogous to an exported ADF pipeline JSON, described here for
readability.)

## Pipeline: `pl_f1_lakehouse_daily`

```mermaid
flowchart LR
    A[Copy Activity<br/>Source -> Files/raw] --> B[Notebook: 01_bronze_ingestion]
    B --> C[Notebook: 02_silver_transformation]
    C --> D[Notebook: 03_gold_aggregation]
    D --> E[Notebook: 04_data_quality_checks]
    E -->|Success| F[Refresh Power BI dataset<br/>optional, Direct Lake needs no refresh]
    E -->|Failure| G[Send failure notification<br/>Teams/Email activity]
```

## Activities

| # | Activity | Type | Depends on | Notes |
|---|---|---|---|---|
| 1 | `copy_source_to_raw` | Copy Data | — | Copies `races.csv`, `drivers.csv`, `constructors.csv`, `results.csv` from the source (file share / API / this repo's `data/` for testing) into the Lakehouse's `Files/raw/` folder |
| 2 | `run_bronze_ingestion` | Notebook | `copy_source_to_raw` succeeded | Runs `notebooks/01_bronze_ingestion.py` |
| 3 | `run_silver_transformation` | Notebook | `run_bronze_ingestion` succeeded | Runs `notebooks/02_silver_transformation.py` |
| 4 | `run_gold_aggregation` | Notebook | `run_silver_transformation` succeeded | Runs `notebooks/03_gold_aggregation.py` |
| 5 | `run_data_quality_checks` | Notebook | `run_gold_aggregation` succeeded | Runs `notebooks/04_data_quality_checks.py --fail-on-error` |
| 6 | `notify_on_failure` | Teams/Email | Any activity failed | Sends a pipeline-failure alert with the failed activity name |

## Parameters

| Parameter | Default | Purpose |
|---|---|---|
| `sourceFilePattern` | `*.csv` | Which files the Copy activity picks up |
| `season` | (none — full reload) | Optional: scope a run to a single season for incremental loads |

## Schedule

- **Trigger**: scheduled, daily at 06:00 UTC (F1 result data doesn't
  change intraday; a daily run is sufficient outside race weekends)
- **Retry policy**: 2 retries with a 5-minute interval on the Copy and
  Notebook activities, to absorb transient source/compute issues

## Notes on incremental loading

The sample pipeline above does a **full reload** each run, which is fine
at this data volume. For a larger/production dataset:
- Add a `season`/`race_date` watermark parameter to the Copy activity so
  only new races are copied
- Change `02_silver_transformation`'s writes from `mode("overwrite")` to
  a `MERGE` (upsert) keyed on the natural key, so re-running doesn't
  rebuild the whole Silver table each time
